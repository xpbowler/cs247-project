# Spells

This is where the spell class and all its subclasses live. 

# Minions

This is where the minion class and all its subclasses live.

#include "apprenticeSummoner.h"
#include "player.h"

//=========================================================
ApprenticeSummoner::ApprenticeSummoner(Player& owner, Player& opponent) 
    : ActivatedMinion (APPRENTICE_SUMMONER_ACTIVATION_COST,
                       APPRENTICE_SUMMONER_ATK, 
                       APPRENTICE_SUMMONER_DEF,
                       owner, opponent, AS, 
                       APPRENTICE_SUMMONER, APPRENTICE_SUMMONER_DESC, APPRENTICE_SUMMONER_COST) {

}


//=========================================================
UseSkillStatus ApprenticeSummoner::useSkill(bool isTesting) {
    if (actions < 1) {
        return NoAction;
    }
    int oldActivationCost = activationCost;
    applyEnchantment(UseAbility);
    if (!canUseAbility) {
        canUseAbility = true;
        activationCost = oldActivationCost;
        return Silenced;
    }
    int magic = owner.getMagic();
    if (magic < activationCost && !isTesting) {
        activationCost = oldActivationCost;
        return NotEnoughMagic;
    }
    summonMinion(AE, 1);
    actions--;
    if (isTesting) {
        owner.setMagic(std::max(0, magic - activationCost));
    }
    else {
        owner.setMagic(magic - activationCost);
    }
    activationCost = oldActivationCost;
    return OK;
}


#pragma once

#include "baseMinion.h"

class AirElemental : public BaseMinion {

public: 
    AirElemental(Player& owner, Player& opponent);

};


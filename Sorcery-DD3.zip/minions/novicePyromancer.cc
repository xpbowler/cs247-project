#include "novicePyromancer.h"
#include <iostream>
#include <stdexcept>
#include <player.h>

//=========================================================
NovicePyromancer::NovicePyromancer(Player &owner, Player &opponent)
    : ActivatedMinion(NOVICE_PYROMANCER_ACTIVATION_COST,
                      NOVICE_PYROMANCER_ATK,
                      NOVICE_PYROMANCER_DEF,
                      owner, opponent, NP, NOVICE_PYROMANCER, NOVICE_PYROMANCER_DESC, NOVICE_PYROMANCER_COST)
{

}

//=========================================================
UseSkillStatus NovicePyromancer::useSkill(bool isTesting)
{
    throw std::runtime_error("should not use skill for novice pyromancer");
}


//=========================================================
UseSkillStatus NovicePyromancer::useSkill(bool isTesting, Minion* minion) {
    if (actions < 1) {
        return NoAction;
    }
    int oldActivationCost = activationCost;
    applyEnchantment(UseAbility);
    if (!canUseAbility) {
        canUseAbility = true;
        activationCost = oldActivationCost;
        return Silenced;
    } 
    int magic = owner.getMagic();
    if (magic < activationCost && !isTesting) {
        activationCost = oldActivationCost;
        return NotEnoughMagic;
    }
    attackMinion(minion, 1, false);
    actions--;
    if (isTesting) {
        owner.setMagic(std::max(0, magic - activationCost));
    }
    else {
        owner.setMagic(magic - activationCost);
    }
    activationCost = oldActivationCost;
    return OK;
}

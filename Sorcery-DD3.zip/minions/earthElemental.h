#pragma once 

#include "baseMinion.h"

class EarthElemental : public BaseMinion {

public: 

    EarthElemental(Player& owner, Player& opponent);
};

  


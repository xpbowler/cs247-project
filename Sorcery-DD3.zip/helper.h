#pragma once

// CONSTANTS
const int STARTING_LIFE = 20;
const int STARTING_MAGIC = 3;
const int STARTING_NUM_CARDS = 5;
const int MAX_HAND_SIZE = 5;
const int AIR_ELEMENTAL_ATK = 1;
const int AIR_ELEMENTAL_DEF = 1;
const int AIR_ELEMENTAL_COST = 0;
const int EARTH_ELEMENTAL_ATK = 4;
const int EARTH_ELEMENTAL_DEF = 4;
const int EARTH_ELEMENTAL_COST = 3;
const int BONE_GOLEM_ATK = 1;
const int BONE_GOLEM_DEF = 3;
const int BONE_GOLEM_COST = 2;
const int FIRE_ELEMENTAL_ATK = 2;
const int FIRE_ELEMENTAL_DEF = 2;
const int FIRE_ELEMENTAL_COST = 2;
const int POTION_SELLER_ATK = 1;
const int POTION_SELLER_DEF = 3;
const int POTION_SELLER_COST = 2;
const int NOVICE_PYROMANCER_ATK = 0;
const int NOVICE_PYROMANCER_DEF = 1;
const int NOVICE_PYROMANCER_COST = 1;
const int NOVICE_PYROMANCER_ACTIVATION_COST = 1;
const int APPRENTICE_SUMMONER_ATK = 1;
const int APPRENTICE_SUMMONER_DEF = 1;
const int APPRENTICE_SUMMONER_COST = 1;
const int APPRENTICE_SUMMONER_ACTIVATION_COST = 1;
const int MASTER_SUMMONER_ATK = 2;
const int MASTER_SUMMONER_DEF = 3;
const int MASTER_SUMMONER_COST = 3;
const int MASTER_SUMMONER_ACTIVATION_COST = 2;
const int CLONER_ATK = 0;
const int CLONER_DEF = 2;
const int CLONER_COST = 3;
const int CLONER_ACTIVATION_COST = 3;
const int GIANT_STRENGTH_COST = 1;
const int ENRAGE_COST = 2;
const int HASTE_COST = 1;
const int MAGIC_FATIGUE_COST = 0;
const int SILENCE_COST = 1;
const int AURA_OF_POWER_COST = 1;
const int AURA_OF_POWER_ACTIVATION_COST = 1;
const int AURA_OF_POWER_CHARGES = 4;
const int DARK_RITUAL_COST = 0;
const int DARK_RITUAL_ACTIVATION_COST = 1;
const int DARK_RITUAL_CHARGES = 5;
const int STANDSTILL_COST = 3;
const int STANDSTILL_ACTIVATION_COST = 2;
const int STANDSTILL_CHARGES = 4;


// Card name constants
inline constexpr const char* AIR_ELEMENTAL = "Air Elemental";
inline constexpr const char* EARTH_ELEMENTAL = "Earth Elemental";
inline constexpr const char* FIRE_ELEMENTAL = "Fire Elemental";
inline constexpr const char* BONE_GOLEM = "Bone Golem";
inline constexpr const char* POTION_SELLER = "Potion Seller";
inline constexpr const char* NOVICE_PYROMANCER = "Novice Pyromancer";
inline constexpr const char* APPRENTICE_SUMMONER = "Apprentice Summoner";
inline constexpr const char* MASTER_SUMMONER = "Master Summoner";
inline constexpr const char* CLONER = "Cloner";
inline constexpr const char* BANISH = "Banish";
inline constexpr const char* UNSUMMON = "Unsummon";
inline constexpr const char* RECHARGE = "Recharge";
inline constexpr const char* DISENCHANT = "Disenchant";
inline constexpr const char* RAISE_DEAD = "Raise Dead";
inline constexpr const char* BLIZZARD = "Blizzard";
inline constexpr const char* ENRAGE = "Enrage";
inline constexpr const char* GIANT_STRENGTH = "Giant Strength";
inline constexpr const char* HASTE = "Haste";
inline constexpr const char* MAGIC_FATIGUE = "Magic Fatigue";
inline constexpr const char* SILENCE = "Silence";
inline constexpr const char* DARK_RITUAL = "Dark Ritual";
inline constexpr const char* AURA_OF_POWER = "Aura of Power";
inline constexpr const char* STANDSTILL = "Standstill";

// Spell costs
const int UNSUMMON_COST = 1;
const int RECHARGE_COST = 1;
const int BLIZZARD_COST = 3;
const int RAISE_DEAD_COST = 1;
const int DISENCHANT_COST = 1;
const int BANISH_COST = 2;

// Minion description constants
inline constexpr const char* BONE_GOLEM_DESC = "Gain +1/+1 whenever a minion leaves play.";
inline constexpr const char* FIRE_ELEMENTAL_DESC = "Whenever an opponent's minion enters play, deal 1 damage to it.";
inline constexpr const char* POTION_SELLER_DESC = "At the end of your turn, all your minions gain +0/+1";
inline constexpr const char* NOVICE_PYROMANCER_DESC = "Deal 1 damage to target minion";
inline constexpr const char* APPRENTICE_SUMMONER_DESC = "Summon a 1/1 air elemental";
inline constexpr const char* MASTER_SUMMONER_DESC = "Summon up to three 1/1 air elementals";
inline constexpr const char* CLONER_DESC = "Summon up to 2 of same type of minions as target minion on the board.";

// Spell description constants
inline constexpr const char* BANISH_DESC = "Destroy target minion or ritual";
inline constexpr const char* UNSUMMON_DESC = "Return target minion to its owner's hand";
inline constexpr const char* RECHARGE_DESC = "Your ritual gains 3 charges";
inline constexpr const char* DISENCHANT_DESC = "Destroy the top enchantment on target minion";
inline constexpr const char* RAISE_DEAD_DESC = "Resurrect the top minion in your graveyard and set its defence to 1";
inline constexpr const char* BLIZZARD_DESC = "Deal 2 damage to all minions";

// Enchantment description constants
inline constexpr const char* GIANT_STRENGTH_DESC = "";
inline constexpr const char* GIANT_STRENGTH_ATTACK = "+2";
inline constexpr const char* GIANT_STRENGTH_DEF = "+2"; 
inline constexpr const char* ENRAGE_DESC = "";
inline constexpr const char* ENRAGE_ATTACK = "*2";
inline constexpr const char* ENRAGE_DEF = "*2";
inline constexpr const char* HASTE_DESC = "Enchanted minion gains +1 action each turn";
inline constexpr const char* MAGIC_FATIGUE_DESC = "Enchanted minion's activated ability costs 2 more";
inline constexpr const char* SILENCE_DESC = "Enchanted minion cannot use abilities";

// Ritual description constants
inline constexpr const char* AURA_OF_POWER_DESC = "Whenever a minion enters play under your control, it gains +1/+1";
inline constexpr const char* DARK_RITUAL_DESC = "At the start of your turn, gain 1 magic";
inline constexpr const char* STANDSTILL_DESC = "Whenever a minion enters play, destroy it";

// Enums
enum Area {
    Deck,
    Hand,
    Board,
    Graveyard
};

enum TriggerType {
    EndTurnPlayer1,
    EndTurnPlayer2,
    StartTurnPlayer1,
    StartTurnPlayer2,
    MinionLeave,
    MinionEnter
};

enum MinionType {
    AE, // air elemental
    EE, // earth elemental 
    NP, // novice pyromancer 
    MS, // master summoner
    AS, // apprentice summoner
    BG, // bone golem
    FE, // fire elemental 
    PS, // potion seller
    CL // cloner
};

const size_t NUM_MINION_TYPES = 9;

enum EnchantmentTiming {
    StartOfTurn, 
    Attack,
    UseAbility, 
    Never
};

enum UseSkillStatus {
    OK, 
    NoAction, 
    Silenced,
    NotEnoughMagic
};

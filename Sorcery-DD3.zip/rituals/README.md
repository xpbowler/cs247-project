# Rituals 

This is where the ritual class and all its subclasses live. 

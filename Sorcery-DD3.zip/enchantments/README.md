# Enchantments

This directory is where the enchantment class and all its subclasses live.
